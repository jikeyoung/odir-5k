#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torchvision import transforms

from model.efficientnet import EfficientNetTwoInput as ODIR_Model
from dataloader import TwoImageDataset
from utils import ODIR_Metrics

def train_one_epoch(model, dataloader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    
    for batch_idx, (img1, img2, labels) in enumerate(dataloader):
        # Move data to device
        img1 = img1.to(device)
        img2 = img2.to(device)
        labels = labels.to(device)

        outputs = model(img1, img2)  # shape: (batch_size, 8)
        loss = criterion(outputs, labels)
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * img1.size(0)

    # Calculate average loss over the dataset
    epoch_loss = running_loss / len(dataloader.dataset)
    return epoch_loss

def validate_one_epoch(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0

    N = len(dataloader.dataset) 
    L = 8 

    all_preds = torch.zeros((N, L), dtype=torch.float32)   
    all_labels = torch.zeros((N, L), dtype=torch.long) 

    start_idx = 0
    with torch.no_grad():
        for img1, img2, labels in dataloader:
            img1 = img1.to(device)
            img2 = img2.to(device)
            labels = labels.to(device)

            outputs = model(img1, img2)  # shape: [batch_size, L]
            loss = criterion(outputs, labels)
            running_loss += loss.item() * img1.size(0)

            probs = torch.sigmoid(outputs)
            batch_size_now = probs.size(0) 
            all_preds[start_idx : start_idx + batch_size_now, :] = probs.cpu()
            all_labels[start_idx : start_idx + batch_size_now, :] = labels.cpu().long()
            start_idx += batch_size_now

    epoch_loss = running_loss / N
    kappa, f1, auc = ODIR_Metrics(all_labels, all_preds)

    return epoch_loss, kappa, f1, auc 

def main():
    # Hyperparameters
    num_epochs = 500
    batch_size = 32 
    learning_rate = 1e-4

    # Decide device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    train_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomRotation(degrees=30),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.ColorJitter(
        brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1
    ),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]) ])

    valid_transforms = transforms.Compose([
        transforms.Resize((224, 224)),  # 固定大小
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])
    
    # Build train and valid datasets
    train_dataset = TwoImageDataset(csv_file="./dataset/ODIR/train_anno.csv", root_dir="./dataset/ODIR/train/Images_Crop/", transform=train_transforms)
    valid_dataset = TwoImageDataset(csv_file="./dataset/ODIR/offsite_anno.csv", root_dir="./dataset/ODIR/offsite/Images_Crop/", transform=valid_transforms)

    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=8)
    valid_dataloader = DataLoader(valid_dataset, batch_size=batch_size, shuffle=False, num_workers=2)

    print('Train images: %s' % len(train_dataloader.dataset))
    print('Valid images: %s' % len(valid_dataloader.dataset))

    # Initialize model, loss function, and optimizer
    model = ODIR_Model(num_classes=8).to(device)
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    # Record the best validation loss
    best_valid_loss = float('inf')

    best_metric = 0.0
    # Training loop
    for epoch in range(num_epochs):
        train_loss = train_one_epoch(model, dataloader=train_dataloader, criterion=criterion, optimizer=optimizer, device=device)
        valid_loss, kappa, f1, auc = validate_one_epoch(model, dataloader=valid_dataloader, criterion=criterion, device=device)
        print(f"Epoch [{epoch+1}/{num_epochs}] (Train Loss: {train_loss:.4f} | Valid Loss: {valid_loss:.4f} | Kappa: {kappa:.4f} | F1-score: {f1:.4f} | AUC: {auc:.4f})")
        avg_metric = (kappa+f1+auc) / 3.

        if avg_metric > best_metric:
            best_metric = avg_metric 
            torch.save(model.state_dict(), './snapshot/best_eff.pth')

            print(f"  ==> Found new best valid loss. Model checkpoint saved!")

    print("Training completed.")

if __name__ == "__main__":
    main()

