import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn import metrics
from torch.utils.data import Dataset, DataLoader

def compute_label_based_metrics(y_true, y_pred, threshold=0.5):
    eps = 1e-7
    y_pred = (y_pred > threshold)

    L = y_true.size(1)

    acc_list = []
    prec_list = []
    rec_list = []

    for label_idx in range(L):
        true_label = y_true[:, label_idx]
        pred_label = y_pred[:, label_idx]

        TP = ((pred_label == 1) & (true_label == 1)).sum().item()
        FP = ((pred_label == 1) & (true_label == 0)).sum().item()
        TN = ((pred_label == 0) & (true_label == 0)).sum().item()
        FN = ((pred_label == 0) & (true_label == 1)).sum().item()

        acc = (TP + TN) / (TP + TN + FP + FN + eps)
        prec = TP / (TP + FP + eps)
        rec = TP / (TP + FN + eps)

        acc_list.append(acc)
        prec_list.append(prec)
        rec_list.append(rec)

    acc_macro = sum(acc_list) / L
    prec_macro = sum(prec_list) / L
    rec_macro = sum(rec_list) / L

    return acc_macro, prec_macro, rec_macro

def compute_label_based_metrics2(y_true, y_pred, threshold):
    eps = 1e-7
    y_pred = (y_pred > threshold)

    L = y_true.size(1)

    sum_tp = 0
    sum_fp = 0
    sum_tn = 0
    sum_fn = 0

    for label_idx in range(L):
        true_label = y_true[:, label_idx]
        pred_label = y_pred[:, label_idx]

        TP = ((pred_label == 1) & (true_label == 1)).sum().item()
        FP = ((pred_label == 1) & (true_label == 0)).sum().item()
        TN = ((pred_label == 0) & (true_label == 0)).sum().item()
        FN = ((pred_label == 0) & (true_label == 1)).sum().item()

        sum_tp += TP
        sum_fp += FP
        sum_tn += TN
        sum_fn += FN

    acc =  (sum_tp + sum_tn) / (sum_tp + sum_tn + sum_fp + sum_fn + eps)
    prc = sum_tp / (sum_tp + sum_fp + eps)
    rec = sum_tp / (sum_tp + sum_fn + eps)

    return acc, prc, rec

def ODIR_Metrics(gt_data, pr_data, th=0.5):
    gt = gt_data.flatten()
    pr = pr_data.flatten()
    kappa = metrics.cohen_kappa_score(gt, pr>th)
    f1 = metrics.f1_score(gt, pr>th, average='micro')
    auc = metrics.roc_auc_score(gt, pr)
    final_score = (kappa+f1+auc)/3.0
    return kappa, f1, auc 

def ODIR_Metrics2(gt_data, pr_data, th=0.5):
    gt = gt_data.flatten()
    pr = pr_data.flatten()
    kappa = metrics.cohen_kappa_score(gt, pr>th)
    acc  = metrics.accuracy_score(gt, pr>th)
    prec = metrics.precision_score(gt, pr>th, average='micro')
    rec  = metrics.recall_score(gt, pr>th, average='micro')
    f1 = metrics.f1_score(gt, pr>th, average='micro')
    auc = metrics.roc_auc_score(gt, pr)
    final_score = (kappa+f1+auc)/3.0
    return kappa, f1, auc, acc, prec, rec 
