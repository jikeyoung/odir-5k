import torch
import torch.nn as nn
import torchvision.models as models

"""
# 整体说明：
# 本脚本实现了一个基于EfficientNet的双输入图像分类模型。
该模型使用EfficientNet作为特征提取器，两个输入图像通过特征拼接（或加法）方式进行处理，最终通过一个全连接层得到多分类输出。
# 用户可以根据需要选择不同版本的EfficientNet（如b0, b1, b2等）。输出层维度默认为8，适用于多标签分类任务。
"""

class EfficientNetTwoInput(nn.Module):
    def __init__(self, num_classes=8, version='b0'):
        """
        初始化函数，定义模型的结构和选择EfficientNet版本。
        num_classes: 输出维度，默认为8，适用于8分类问题。
        version: 选择EfficientNet的版本（'b0', 'b1', 'b2'等），默认为'b0'。
        """
        super(EfficientNetTwoInput, self).__init__()

        # 1) 使用预训练的EfficientNet模型
        # 通过torchvision.models加载EfficientNet，并选择所需的版本
        self.efficientnet = models.efficientnet_b2(pretrained=True)

        # 2) 获取EfficientNet最后一层的输入特征维度
        in_features = self.efficientnet.classifier[1].in_features

        # 3) 替换最后的分类层，用 Identity 让网络只输出特征向量 (1280-d)
        # EfficientNet的分类层通常是一个Dropout层加一个Linear层，我们将其替换为Identity层，这样网络就只会输出1280维的特征，而不是分类结果。
        #    efficientnet_b0.classifier通常是 nn.Sequential(
        #       (0): nn.Dropout(...)
        #       (1): nn.Linear(1280, 1000)
        #    )
        self.efficientnet.classifier[1] = nn.Identity()

        # 4) 定义自己的分类器，输入大小 = 2倍的 in_features (因为双输入拼接)
        #    输出大小 = num_classes (默认为8)
        #self.classifier = nn.Linear(in_features * 2, num_classes)
        self.classifier = nn.Linear(in_features, num_classes)
        """
        如果选择拼接两个特征： 应该使用 nn.Linear(in_features * 2, num_classes)。
        如果选择相加两个特征： 应该使用 nn.Linear(in_features, num_classes)。
        """

    def forward(self, img1, img2):
        """
        前向传播函数，处理两个输入图像。
        img1, img2: 输入图像，形状为 [batch_size, 3, H, W]，即一批图像，RGB通道，高度H和宽度W。
        return: 输出分类结果，形状为 [batch_size, num_classes]。
        """

        # 1) 提取第一个输入图像的特征
        feat1 = self.efficientnet(img1)  # 输出特征形状为 [batch_size, 1280]

        # 2) 提取第二个输入图像的特征
        feat2 = self.efficientnet(img2)  # 输出特征形状为 [batch_size, 1280]

        # 3) 将两个特征进行拼接或相加
        # 如果使用拼接，形状会变成 [batch_size, 2560]，可以通过 torch.cat 完成
        # 这里使用的是加法，即将两个特征逐元素相加，输出形状为 [batch_size, 1280]
        combined = feat1 + feat2
        #combined = torch.cat((feat1, feat2), dim=1)

        # 4) 将组合后的特征传递通过分类器进行分类
        out = self.classifier(combined)  # 输出分类结果，形状为 [batch_size, 8]

        return out