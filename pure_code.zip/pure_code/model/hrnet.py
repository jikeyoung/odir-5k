
# -*- coding: utf-8 -*-

"""
hrnet.py

A single-file, minimal HRNet implementation (single-scale branch)
plus a two-input extension (HRNetTwoInput) that processes two images
and concatenates their features for final classification.
极简HRNet实现（单分支版本）及双输入扩展版本
- 支持单输入图像分类任务
- 扩展支持双输入图像（如双眼）的特征拼接分类
基于HRNet官方实现简化，适用于分类任务

主要结构：
1. 基础残差模块（BasicBlock/Bottleneck）
2. 单分支高分辨率模块（HighResolutionModule）
3. 主网络HRNet（支持特征提取）
4. 双输入扩展网络HRNetTwoInput（处理两幅图像输入）

Based on and simplified from:
https://github.com/HRNet/HRNet-Image-Classification

MIT License
(C) 2019-present Microsoft
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# 1. 基础残差模块: BasicBlock, Bottleneck
# ---------------------------------------------------------------------------
class BasicBlock(nn.Module):
    """基础残差块（ResNet-18风格）"""
    expansion = 1  # 输出通道扩展系数, 1表示不扩展
    def __init__(self, inplanes, planes, stride=1, downsample=None):
        """
        Args:
            inplanes: 输入通道数
            planes: 中间层通道数
            stride: 卷积步长
            downsample: 下采样函数（用于调整维度）
        """
        super(BasicBlock, self).__init__()
        # 第一层卷积：3x3卷积+BN+ReLU
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3,
                               stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)

        # 第二层卷积：3x3卷积+BN
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)

        self.downsample = downsample  # 下采样模块
        self.stride = stride

    def forward(self, x):
        identity = x  # 残差连接(恒等映射)

        # 主路径处理
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        # 调整残差维度
        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity   # 残差相加
        out = self.relu(out)
        return out


class Bottleneck(nn.Module):
    """瓶颈残差块（ResNet-50+风格）"""
    expansion = 4  # 输出通道扩展系数，意思是每个block的输出通道数是输入通道数的4倍
    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        # 第一层：1x1卷积压缩通道
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)

        # 第二层：3x3卷积提取特征
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3,
                               stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)

        # 第三层：1x1卷积恢复通道
        self.conv3 = nn.Conv2d(planes, planes * self.expansion,
                               kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion)

        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)
        return out


# ---------------------------------------------------------------------------
# 2. Minimal single-scale HighResolutionModule (really just a basic block stage here)
#    单分支高分辨率模块
# ---------------------------------------------------------------------------
class HighResolutionModule(nn.Module):
    """
    简化高分辨率模块（单分支版本）
    Simplified: single-branch stage in HRNet.
    In real HRNet, you'd have multiple branches & fuse them. 
    Here, we only do a single scale for demonstration.
    """
    def __init__(self, num_branches, block, num_blocks, in_channels, num_channels):
        """
        Args:
            num_branches: 分支数（此处固定为1）
            block: 残差块类型（BasicBlock或Bottleneck）
            num_blocks: 每个阶段的残差块数量
            in_channels: 输入通道数列表
            num_channels: 各分支通道数配置
        """
        super(HighResolutionModule, self).__init__()
        # single-branch simplified
        self.blocks = block
        self.in_channels = in_channels
        self.num_channels = num_channels
        self.num_branches = num_branches

        # 构建单分支残差层序列
        branch_layers = []
        out_chan = num_channels[0]  # 当前分支的输出通道数
        layers = []

        # 逐层构建残差块
        for i in range(num_blocks[0]): 
            downsample = None
            expected_out_c = out_chan * self.blocks.expansion   # 计算预期输出通道数

            # 如果当前分支的输入通道数与预期输出通道数不一致，则需要进行下采样
            if in_channels[0] != expected_out_c:
                downsample = nn.Sequential(
                    nn.Conv2d(in_channels[0], expected_out_c, kernel_size=1, stride=1, bias=False),
                    nn.BatchNorm2d(expected_out_c))

            # 创建残差块并更新输入通道
            block = self.blocks(in_channels[0], out_chan, stride=1, downsample=downsample)
            layers.append(block)
            in_channels[0] = expected_out_c

        branch_layers.append(nn.Sequential(*layers))
        self.branches = nn.ModuleList(branch_layers)  # 注册分支模块

    def forward(self, x):
        x0 = self.branches[0](x)  # 单分支前向传播
        return x0


# ---------------------------------------------------------------------------
# 3. The main HRNet class (single-scale)
#    HRNet主网络（单分支版本）
# ---------------------------------------------------------------------------
class HRNet(nn.Module):
    """
    极简HRNet主网络（单分支版本）
    A minimal single-scale HRNet-like model for classification.
    If you want features only, you can call forward_features(x).
    """
    def __init__(self, block, layers, num_classes=1000):
        """
        Args:
            block: 残差块类型（BasicBlock/Bottleneck）
            layers: 各阶段残差块数量配置
            num_classes: 分类类别数
        """
        super(HRNet, self).__init__()
        self.inplanes = 64  # 初始通道数

        # 输入预处理（STEM）
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=2,
                               padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv2d(64, 64, kernel_size=3, stride=2,
                               padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(64)
        self.relu2 = nn.ReLU(inplace=True)

        # 构建四个阶段的残差层序列
        # Stage1
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.transition1 = nn.Identity()  # 阶段间过渡（此处无操作）

        # Stage2
        stage2_num_channels = [64]
        self.stage2 = HighResolutionModule(
            num_branches=1,
            block=block,
            num_blocks=[layers[1]],
            in_channels=[self.inplanes],
            num_channels=stage2_num_channels
        )
        self.inplanes = stage2_num_channels[0] * block.expansion

        # Stage3
        stage3_num_channels = [128]
        self.stage3 = HighResolutionModule(
            num_branches=1,
            block=block,
            num_blocks=[layers[2]],
            in_channels=[self.inplanes],
            num_channels=stage3_num_channels
        )
        self.inplanes = stage3_num_channels[0] * block.expansion

        # Stage4
        stage4_num_channels = [256]
        self.stage4 = HighResolutionModule(
            num_branches=1,
            block=block,
            num_blocks=[layers[3]],
            in_channels=[self.inplanes],
            num_channels=stage4_num_channels
        )
        self.inplanes = stage4_num_channels[0] * block.expansion

        # 分类头
        self.avgpool = nn.AdaptiveAvgPool2d((1,1))        # 全局平均池化
        self.fc = nn.Linear(self.inplanes, num_classes)   # 全连接层

    def _make_layer(self, block, planes, blocks, stride=1):
        """构建残差层序列"""
        downsample = None
        # 当维度不匹配时创建下采样模块
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion  # 更新输入通道
        # 添加后续残差块
        for _ in range(1, blocks):
            layers.append(block(self.inplanes, planes))
        return nn.Sequential(*layers)

    def forward_features(self, x):
        """Forward pass until before the final FC layer. Returns a 1D vector."""
        """特征提取流程（输出分类前的特征向量）"""

        # STEM处理
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)

        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu2(x)

        # 逐阶段处理
        # Stage1
        x = self.layer1(x)
        x = self.transition1(x)

        # Stage2
        x = self.stage2(x)

        # Stage3
        x = self.stage3(x)

        # Stage4
        x = self.stage4(x)

        # 全局池化并展平
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        return x

    def forward(self, x):
        """Full classification forward."""
        """完整分类流程"""
        x = self.forward_features(x)
        x = self.fc(x)
        return x


def get_hrnetv2_w32(num_classes=1000):
    """
    Instantiate a minimal HRNetV2-W32-like model for classification(single-scale).
    layers=[2, 2, 2, 2] is just an example.
    """
    """实例化HRNet-W32配置（示例参数）"""
    # 使用Bottleneck块，各阶段2个残差块
    model = HRNet(block=Bottleneck, layers=[2, 2, 2, 2], num_classes=num_classes)
    return model


# ---------------------------------------------------------------------------
# 4. Double Input HRNet for classification
#    双输入HRNet扩展
# ---------------------------------------------------------------------------
class HRNetTwoInput(nn.Module):
    """
    Use one HRNet backbone, pass two images (img1, img2),
    extract features from each, then concat -> final classifier.
    """
    """双输入HRNet（处理两幅图像拼接特征）"""

    def __init__(self, num_classes=8):
        super(HRNetTwoInput, self).__init__()
        # Create a single-scale HRNet (w32 as example)
        # 创建基础HRNet并移除原分类头
        self.hrnet = get_hrnetv2_w32(num_classes=1000)
        # Remove (or ignore) the final fc in hrnet, we'll do our own classifier
        self.hrnet.fc = nn.Identity() # 禁用原全连接层

        # HRNet output feature dim = 256 * 4 = 1024? (Based on above config)
        # Actually let's print: self.hrnet.inplanes might be 256 * 4 = 1024
        # But in the final stage, stage4 => 256 * Bottleneck.expansion=4 => 1024
        # 特征拼接后的分类层
        in_features = 1024   # 根据Bottleneck配置计算的特征维度
        # Our custom classifier for 2 images => concat => 2 * in_features
        self.classifier = nn.Linear(in_features * 2, num_classes)  # 拼接后维度翻倍

    def forward(self, img1, img2):
        # 分别提取两幅图像特征
        feat1 = self.hrnet.forward_features(img1)  # shape: [B, 1024]
        feat2 = self.hrnet.forward_features(img2)  # shape: [B, 1024]

        # 拼接特征并分类
        combined = torch.cat((feat1, feat2), dim=1)  # [B, 2048]
        out = self.classifier(combined)              # [B, num_classes]
        return out


# ---------------------------------------------------------------------------
# 5. Demo
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("Testing single-scale HRNet & HRNetTwoInput...")

    # Single image HRNet （单输入网络）
    net = get_hrnetv2_w32(num_classes=10)
    dummy = torch.randn(1, 3, 224, 224)       # 生成测试数据，shape: [1, 3, 224, 224]
    logits = net(dummy)
    print("Single HRNet output:", logits.shape)  # 应输出 [1, 10]
    print(logits)

    # Double input HRNet（双输入网络）
    two_in_net = HRNetTwoInput(num_classes=8)
    dummy1 = torch.randn(1, 3, 224, 224)
    dummy2 = torch.randn(1, 3, 224, 224)
    out2 = two_in_net(dummy1, dummy2)
    print("TwoInput HRNet output:", out2.shape)  # [1, 8]
    print(out2)

