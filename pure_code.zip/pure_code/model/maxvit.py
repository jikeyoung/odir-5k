import torch
import torch.nn as nn
from torchvision import models



"""
# 该模型是一个基于MaxViT的双输入模型，结合了注意力融合和特征拼接的方式进行图像特征融合，最后通过分类器输出预测结果。
# 具体实现包括MaxViT网络和两种特征融合方式：AttentionFusion和ConcatFusion。可以根据实际需求选择不同的融合方式。
"""

# 注意力融合类
class AttentionFusion(nn.Module):
    """
    AttentionFusion类通过注意力机制对两个输入的特征进行加权融合。
    通过计算一个基于输入特征的注意力权重，将左右输入特征融合。
    """
    def __init__(self, in_features, num_classes):
        super(AttentionFusion, self).__init__()
        # 定义一个全连接层来生成注意力权重，输入特征维度为2*in_features，输出特征维度为in_features
        self.att_fc = nn.Linear(in_features * 2, in_features)
        # 定义一个全连接层来输出最终的分类结果
        self.fc = nn.Linear(in_features, num_classes)
        # 激活函数，ReLU函数
        self.relu = nn.ReLU(inplace=True)
        # Sigmoid函数，将注意力权重归一化到0~1之间
        self.sigmoid = nn.Sigmoid()


    def forward(self, f_left, f_right):
        # 将左侧和右侧的特征拼接在一起，形状变为 [B, 2*d]
        concat = torch.cat((f_left, f_right), dim=1)
        # 计算注意力权重，形状为 [B, d]，值在0~1之间
        att = self.sigmoid(self.att_fc(concat))
        # 融合两个特征，注意力机制加权
        fused = att * f_left + (1 - att) * f_right
        # 使用ReLU激活函数对融合后的特征进行激活
        fused = self.relu(fused)
        # 将融合后的特征通过分类器输出最终结果
        out = self.fc(fused)
        return out


# 拼接融合类
class ConcatFusion(nn.Module):
    """
    ConcatFusion类通过简单地将两个输入特征拼接并经过全连接层进行分类。
    该方法没有使用复杂的注意力机制，仅通过拼接后进行全连接层处理。
    """

    def __init__(self, in_features, hidden_features, num_classes):
        super(ConcatFusion, self).__init__()
        # 定义第一个全连接层，用于将拼接后的特征转换为hidden_features维度
        self.fc1 = nn.Linear(in_features * 2, hidden_features)
        # 激活函数，ReLU函数
        self.relu = nn.ReLU(inplace=True)
        # Dropout层，防止过拟合，dropout概率为0.5
        self.dropout = nn.Dropout(p=0.5)
        # 定义第二个全连接层，用于输出最终分类结果
        self.fc2 = nn.Linear(hidden_features, num_classes)

    def forward(self, f_left, f_right):
        # 将左侧和右侧的特征拼接在一起，形状变为 [B, 2*d]
        fused = torch.cat((f_left, f_right), dim=1)
        # 通过第一个全连接层转换特征
        x = self.fc1(fused)
        # 使用ReLU激活函数对特征进行激活
        x = self.relu(x)
        # 使用Dropout进行正则化
        x = self.dropout(x)
        # 通过第二个全连接层输出最终结果
        out = self.fc2(x)
        return out


# MaxViT模型类，处理两个输入图像并输出分类结果
class MaxViTTwoInput(nn.Module):
    """
    MaxViTTwoInput类通过MaxViT网络提取两个输入图像的特征，
    并结合特征融合模块（AttentionFusion或ConcatFusion）输出最终的分类结果。
    """

    def __init__(self, num_classes=8):
        super().__init__()
        # 加载预训练的MaxViT模型（预训练模型权重来自ImageNet）
        self.maxvit = models.maxvit_t(weights=models.MaxVit_T_Weights.IMAGENET1K_V1)
        # 将MaxViT的最后一个分类层去除，保留特征提取部分
        self.maxvit.classifier[-1] = nn.Identity()
        # 选择特征融合方式：AttentionFusion或者ConcatFusion
        self.att = AttentionFusion(512, num_classes)
        # self.att = ConcatFusion(512, 128, num_classes)

    def forward(self, img1, img2):
        # 使用MaxViT提取图像1的特征，输出维度为[B, 768]
        feat1 = self.maxvit(img1)
        # 使用MaxViT提取图像2的特征，输出维度为[B, 768]
        feat2 = self.maxvit(img2)
        # 将两张图像的特征进行融合，并通过分类器输出最终结果
        out = self.att(feat1, feat2)
        return out