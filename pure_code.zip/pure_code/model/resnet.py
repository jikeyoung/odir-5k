import torch
import torch.nn as nn
from torchvision import models


"""
这个 ResNetTwoInput 类是一个双输入图像分类模型，
使用了 ResNet 作为骨干网络（backbone），并将两个输入图像的特征拼接后通过一个分类器进行最终的分类预测。
1. 整体结构
   - 该模型支持使用两种不同的 ResNet 变体作为 backbone：resnet50 和 resnet101。
   - Backbone 的最后一层（全连接层 fc）被替换为 nn.Identity()，这意味着模型只提取特征，而不进行分类。
   - 提取的特征是从 ResNet 输出的全局特征，维度为 2048。
   - 两张图像的特征会在最后一层通过 torch.cat() 拼接，拼接后的特征维度为 4096（2048 * 2）。
   - 拼接后的特征会输入到一个全连接层（self.classifier），输出最终的类别预测。
"""


class ResNetTwoInput(nn.Module):
    def __init__(self, backbone='resnet50', num_classes=8):
        super(ResNetTwoInput, self).__init__()
        
        # 根据需要选择不同的 backbone
        if backbone == 'resnet50':
            self.backbone = models.resnet50(pretrained=True)   # 加载预训练的 ResNet50 模型
        elif backbone == 'resnet101':
            self.backbone = models.resnet101(pretrained=True)  # 加载预训练的 ResNet101 模型
        else:
            raise ValueError("Unsupported backbone. Use 'resnet50' or 'resnet101'.")
        
        # 将 ResNet 的最后一层全连接层（fc）替换为 nn.Identity()，使得模型只提取特征
        self.backbone.fc = nn.Identity()
        
        # 假设 backbone 输出特征维度为 2048
        in_features = 2048
        # 双输入的拼接后特征维度为 2048 * 2 = 4096
        # 分类器为一个全连接层，将拼接后的特征映射到 num_classes 类别
        self.classifier = nn.Linear(in_features * 2, num_classes)

    def forward(self, img1, img2):
        # 使用 backbone 分别提取两张输入图像的特征
        feat1 = self.backbone(img1)  # feat1 的维度为 [B, 2048]
        feat2 = self.backbone(img2)  # feat2 的维度为 [B, 2048]

        # 将两张图像的特征拼接，拼接后的特征维度为 [B, 4096]
        combined = torch.cat((feat1, feat2), dim=1)

        # 将拼接后的特征传递给分类器进行分类，输出维度为 [B, num_classes]
        out = self.classifier(combined)
        return out