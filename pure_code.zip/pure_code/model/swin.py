import torch
import torch.nn as nn
import torchvision.models as models

"""
这段代码定义了一个名为 SwinTransformerTwoInput 的深度学习模型，
它使用了 Swin Transformer（一个流行的视觉 Transformer 模型）作为骨干网络（backbone）。
该模型接受两张输入图像，并将它们的特征拼接后进行分类.
# 整体结构
    - 模型使用不同变种的 Swin Transformer（swin_s, swin_b, swin_v2_s, swin_v2_b）作为骨干网络。
    - Swin Transformer 提取图像特征时，去掉了原本用于分类的头部层（self.swin.head = nn.Identity()），这样模型只输出提取的特征。
    - 两张图像的特征会被拼接（torch.cat），拼接后的特征输入到一个全连接层（self.classifier）进行最终的分类。
"""


class SwinTransformerTwoInput(nn.Module):
    def __init__(self, num_classes=8, variant='swin_v2_b'):
        super(SwinTransformerTwoInput, self).__init__()

        # 根据传入的 variant 加载不同的 Swin Transformer 模型
        if variant == 'swin_s':
            # 加载 swin_s 变体，使用预训练的权重
            self.swin = models.swin_s(weights=models.Swin_S_Weights.IMAGENET1K_V1)
        elif variant == 'swin_b':
            # 加载 swin_b 变体，使用预训练的权重
            self.swin = models.swin_b(weights=models.Swin_B_Weights.IMAGENET1K_V1)
        elif variant == 'swin_v2_s':
            # 加载 swin_v2_s 变体，使用预训练的权重
            self.swin = models.swin_v2_s(weights=models.Swin_V2_S_Weights.IMAGENET1K_V1)
        elif variant == 'swin_v2_b':
            # 加载 swin_v2_b 变体，使用预训练的权重
            self.swin = models.swin_v2_b(weights=models.Swin_V2_B_Weights.IMAGENET1K_V1)
        else:
            # 如果传入的 variant 不是已知的类型，则抛出错误
            raise ValueError(f"Unknown variant: {variant}")

        # 获取 Swin Transformer 模型输出特征的维度
        in_features = self.swin.head.in_features

        # 替换模型的分类头部，使其只提取特征而不进行分类
        self.swin.head = nn.Identity()

        # 定义一个全连接层，将双输入拼接后的特征映射到最终的分类空间
        self.classifier = nn.Linear(in_features * 2, num_classes)

    def forward(self, img1, img2):
        # 分别通过 Swin Transformer 提取两张图像的特征
        feat1 = self.swin(img1)  # 特征维度为 [batch_size, in_features]
        feat2 = self.swin(img2)  # 特征维度为 [batch_size, in_features]

        # 将两张图像的特征进行拼接，拼接后的维度为 [batch_size, in_features * 2]
        combined = torch.cat((feat1, feat2), dim=1)

        # 通过全连接分类器进行最终的分类
        out = self.classifier(combined)
        return out