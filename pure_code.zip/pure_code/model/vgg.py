import torch
import torch.nn as nn
from torchvision import models

"""
这段代码定义了一个名为 VGGTwoInput 的深度学习模型，使用了 VGG16 作为骨干网络（backbone），并接收两张输入图像，提取它们的特征后进行分类。
与传统的 VGG16 模型不同，代码中有一些定制的部分，例如替换 VGG16 的最后一层，并将两张图像的特征通过加法操作融合，而不是简单地拼接。
1. 整体结构
    - 使用了预训练的 VGG16 模型作为骨干网络。
    - 删除了 VGG16 模型中的最后一个分类层（使得模型输出的特征维度为 4096）。
    - 对于两张输入图像，提取它们的特征后，通过加法操作将它们合并，而不是使用拼接。
    - 最后通过一个全连接层进行分类。
2.特征融合方式：
    - 该模型选择了通过加法（而不是拼接）将两张图像的特征融合。加法合并可能在某些任务中表现较好，尤其是在特征维度相同的情况下。通过加法合并，模型能够“聚焦”于两个输入图像的共享信息。
    - 拼接通常用于希望模型捕捉到更多的信息（增加维度），而加法则是一个较为简单且对称的操作，强调特征之间的“交互”。
"""


class VGGTwoInput(nn.Module):
    def __init__(self, num_classes=8):
        """
        初始化 SwinTransformerTwoInput 模型
        :param num_classes: 输出类别数
        :param variant: Swin Transformer 的变种，可选 'swin_s', 'swin_b', 'swin_v2_s', 'swin_v2_b'
        """
        super(VGGTwoInput, self).__init__()

        # 加载预训练的 VGG16 模型
        self.vgg = models.vgg16(weights=models.VGG16_Weights.DEFAULT)

        # 替换 VGG16 的分类器部分
        # 默认的 vgg16.classifier 是一个顺序模块，包含如下几层：
        # [Linear(25088, 4096), ReLU, Dropout, Linear(4096,4096), ReLU, Dropout, Linear(4096,1000)]
        #
        # 我们去掉最后一层，保留前面的层，使得输出为 4096 维的特征向量。
        self.vgg.classifier = nn.Sequential(*list(self.vgg.classifier.children())[:-1])
        # 现在，self.vgg(...) 会返回每张图像的 4096 维特征。

        # 定义一个新的分类器，用于处理拼接后的特征。
        # 因为我们要拼接两张图像的特征，所以特征维度将翻倍：4096 * 2 = 8192
        #self.classifier = nn.Linear(4096 * 2, num_classes)
        self.classifier = nn.Linear(4096, num_classes)

    def forward(self, img1, img2):
        """
        前向传播
        :param img1: 第一个输入图像，形状为 [batch_size, 3, H, W]
        :param img2: 第二个输入图像，形状为 [batch_size, 3, H, W]
        :return: 分类结果，形状为 [batch_size, num_classes]
        """

        # 从每张图像中提取特征
        feat1 = self.vgg(img1)  # 输出形状： (batch_size, 4096)
        feat2 = self.vgg(img2)  # 输出形状： (batch_size, 4096)

        # 将两张图像的特征通过加法合并
        # combined = torch.cat((feat1, feat2), dim=1)  # 拼接后的形状： (batch_size, 8192)
        combined = feat1 + feat2  # 加法合并，形状： (batch_size, 4096)

        # 通过最终的分类层进行分类
        out = self.classifier(combined)  # 输出形状： (batch_size, num_classes=8)
        return out