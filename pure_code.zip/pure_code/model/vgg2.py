import torch
import torch.nn as nn
from torchvision import models

"""
这段代码定义了一个名为 VGGTwoInput 的深度学习模型，它结合了 VGG16 模型和一些注意力机制模块来处理两张输入图像。
具体来说，模型使用了 Depthwise Separable Convolution、Squeeze-and-Excitation (SE) Block 和 Attention Block 来增强特征表达能力，
并通过两张输入图像的特征进行分类。

1. 整体结构
    - VGG16 Backbone：首先加载预训练的 VGG16 网络，并使用其特征提取部分（去除分类头）。
    - Depthwise Separable Convolution：用于减少计算量的卷积操作。
    - Attention Mechanisms：通过注意力机制模块（AttentionBlock），增强特征的表达能力。
    - 分类器：使用全局平均池化（GAP）层对拼接后的特征进行降维，并通过全连接层进行分类。
2. 各部分的功能
 - Depthwise Separable Convolution：用于减少计算量的卷积操作。
 - SE Block：通过全局平均池化和全连接层实现通道注意力。
 - Attention Block：结合了 DepthwiseSeparableConv 和 SENetBlock，以深度可分离卷积减少计算量，并通过通道注意力增强特征的表达。


3. 总结
VGGTwoInput 模型利用了 VGG16 和深度可分离卷积的组合，并通过注意力机制增强了图像的特征表达。
通过对两张输入图像的特征进行处理、拼接，并使用全局平均池化和全连接层进行分类，适用于图像对比和匹配任务。
"""


class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super(DepthwiseSeparableConv, self).__init__()
        # Depthwise卷积，分离卷积的核心部分
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size, stride, padding, groups=in_channels,
                                   bias=False)
        # Pointwise卷积，将通道数映射到输出通道
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)

    def forward(self, x):
        # Depthwise卷积，执行逐通道卷积操作
        x = self.depthwise(x)
        # Pointwise卷积，执行1x1卷积操作
        x = self.pointwise(x)
        return x


class SENetBlock(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super(SENetBlock, self).__init__()
        # 全局平均池化
        self.global_avg_pool = nn.AdaptiveAvgPool2d(1)
        # 两个全连接层，用于计算通道注意力
        self.fc1 = nn.Linear(in_channels, in_channels // reduction, bias=False)
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Linear(in_channels // reduction, in_channels, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 获取输入张量的尺寸：batch_size, channels, height, width
        b, c, _, _ = x.size()
        # 进行全局平均池化，输出形状为 (batch_size, channels)
        y = self.global_avg_pool(x).view(b, c)
        # 第一层全连接
        y = self.fc1(y)
        y = self.relu(y)
        # 第二层全连接
        y = self.fc2(y)
        # 激活函数
        y = self.sigmoid(y).view(b, c, 1, 1)
        # 通过注意力机制加权输入特征
        return x * y


class AttentionBlock(nn.Module):
    def __init__(self, in_channels):
        super(AttentionBlock, self).__init__()
        # Depthwise separable convolution
        self.dsconv = DepthwiseSeparableConv(in_channels, in_channels)
        # 1x1 卷积用于进行特征映射
        self.pconv = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)
        # 批归一化
        self.bn = nn.BatchNorm2d(in_channels)
        # ReLU 激活函数
        self.relu = nn.ReLU(inplace=True)
        # Squeeze-and-Excitation块
        self.se = SENetBlock(in_channels)

    def forward(self, x):
        # 保存原始输入，用于快捷连接
        identity = self.dsconv(x)
        # 经过1x1卷积和批归一化的处理
        x = self.pconv(x)
        x = self.bn(x)
        x = self.relu(x)
        # 将经过处理的特征和原始输入加和，经过SENet块加权
        return self.se(identity + x)


class VGGTwoInput(nn.Module):
    def __init__(self, num_classes=8):
        super(VGGTwoInput, self).__init__()
        # 加载预训练的 VGG16 模型
        self.vgg = models.vgg16(weights=models.VGG16_Weights.DEFAULT)
        # 截取 VGG16 特征提取部分的前30层，输出14x14的特征图
        self.vgg_t = nn.Sequential(*list(self.vgg.features.children())[:30])  # 14x14特征

        # 定义两个注意力模块
        self.att1 = AttentionBlock(512)
        self.att2 = AttentionBlock(512)
        # 全局平均池化（GAP）
        self.gap = nn.AdaptiveAvgPool2d(1)
        # 分类层，输出类别数
        self.fc = nn.Linear(512 * 2, num_classes)

    def forward(self, img1, img2):
        # 从每张图像中提取特征
        feat1 = self.vgg_t(img1)  # 输出形状: (batch_size, 512, 14, 14)
        feat2 = self.vgg_t(img2)  # 输出形状: (batch_size, 512, 14, 14)

        # 将提取的特征输入到对应的注意力模块
        att1 = self.att1(feat1)
        att2 = self.att2(feat2)

        # 拼接两个图像的特征
        combined = torch.cat((att1, att2), dim=1)  # 拼接后形状: (batch_size, 1024, 14, 14)

        # 全局平均池化
        gap = self.gap(combined)
        # 扁平化输出
        gap = torch.flatten(gap, 1)

        # 通过全连接层进行分类
        out = self.fc(gap)
        return out
